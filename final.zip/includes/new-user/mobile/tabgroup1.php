<?php
echo '
<div class="Mobi-tabs Flexed-row">
<button>
    <section class="Tab1">
       <h4 class="m-l-20"> <a class="Decoration-none" href="../../../new-user.php"> New User</a></h4>
    </section>
</button>
<button>
    <section class="Tab2">
       <h4> <a class="Decoration-none" href="../../../index.php">Log in</a></h4>
    </section>
</button>
</div>
';
?>