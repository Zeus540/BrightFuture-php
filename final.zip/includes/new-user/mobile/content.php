<?php
echo '
<div class="Content-box Flexed-column ">
<section >
    <p class="m-t-10">
        In Hygienica, you’ll enjoy loads
        of fun-filled hygiene adventures where
        you’ll learn all about washing your hands,
        brushing your teeth and spotting invisible
        germs with your friends Sizwe and Lizzy.
    </p>
   
    <p class="m-t-10">
        As you venture through the castle 
        you’ll also earn tons of germ-busting
        bucks which you can redeem for awesome
        real-life prizes for you and your family!
    </p>
    
    <p class="m-t-10"> 
        Sign up now to create your profile.
        Help your little one learn all about
        good hygiene in a fun and
        engaging way.
    </p>
</section>
<section class="center m-t-10">
       <a href="../../../createprofile.php"><button type="submit ">Create profile</button></a>
</section>
</div>
';
?>