<?php
echo '
<div class="Mobi-tabs Flexed-row">
<button>
    <section class="Tab1">
    <a href="../../../new-user.php" class="Decoration-none"><h4 class="m-l-20">New User</h4></a>
    </section>
</button>
<button>
    <section class="Tab2">
       <a href="../../../index.php" class="Decoration-none"><h4>Log in</h4></a>
    </section>
</button>
</div>
';
?>