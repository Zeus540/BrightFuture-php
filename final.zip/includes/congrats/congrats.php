<?php
echo '
<div class="Login Flexed-row ">
<section >
    <img id="congrats-boy-image" src="./assets/images/BoyCharacter1.png" alt="">
</section>
<section class="Rounded Flexed-row">

    <div id="congrats-user-block">
    <img id="congrats-img" src="../../assets/images/Confetti.png" alt="">
       <div>
           <h1>Congratulations!</h1>
           <p>You’ve successfully created you account.
            Please confirm your e-mail address</p>
            <button>
            Confirm
        </button>
       </div>
    </div>
    
</section>
<section>
        <img id="congrats-girl-image" src="./assets/images/GirlCharacter.png" alt="">
</section>
<div>
        <img id="congrats-bottom-right-bg" src="./assets/images/Sizwe&Lizzy.png" alt="" >
</div>
</div>
';
?>