<?php
echo '
<div class="Congrats-content-box Flexed-column ">

<section class="Congrats-img-mobile">

   <img id="coffeti-mobile" src="../../../assets/images/mobi/Group16.png" alt="" width="100%">

</section>

<div class="Content-box">
<section>

   <h1 class="Text-center Heading Mobile-heading">Congratulations!</h1>
   <p class="Text-center " id="congrats-intro-text">You’ve successfully created you account. <br>
    Please confirm your e-mail address</p>
    <p class="Text-center" id="congrats-intro-text2"><a href="" class="Link Bold ">Resend password reset email</a></p>

    <div class="Flexed-row" id="back">
        <a href="../../../index.php" class="Flexed-row Align-center Decoration-none">
            <img src="../../../assets/images/mobi/back.png" alt="" width="20px">&nbsp;&nbsp;
        <p class="Accent Bold">Back to Log in</p></a>
    </div>

</section>
</div>

</div>
';
?>