<?php
echo '
<div class="Header Flexed-row ">
<section class="Logo">
    <img id="logo" src="../assets/images/LOGO.png" alt="">
</section>
<section class="Banner-top center">
    <a href="/"><img id="Banner-top-center" src="../assets/images/VectorSmartObject.png" alt=""></a>
</section>
<section>
        <img id="top-right-cloud" src="../assets/images/Group19.png" alt="">
</section>
</div>
';
?>