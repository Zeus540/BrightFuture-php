<?php
echo '
<div class="Footer">
</div>
';
?>