<?php
echo '
<div class="Login Flexed-row ">
<section >
    <img id="Create-profile-boy-image" src="./assets/images/BoyCharacter1.png" alt="">
</section>
<section class="Rounded Flexed-row">
   
    <div id="forgot-password-user-block">
       <img src="../../assets/images/lock.png" alt="">
       <div>
           <h1>Forgot<br>your password?</h1>
       </div>
       <button>
           Reset Password
       </button>
    </div>

</section>
<section>
        <img id="Create-profile-girl-image" src="./assets/images/GirlCharacter.png" alt="">
</section>
<div>
        <img id="Create-profile-bottom-right-bg" src="./assets/images/Sizwe&Lizzy.png" alt="" >
</div>
</div>
';
?>