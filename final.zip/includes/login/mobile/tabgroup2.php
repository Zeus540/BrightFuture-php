<?php
echo '
<div class="Mobi-tabs-2 Flexed-row">
<section class="Tab3 ">
    <h5 class="m-l-20">Registered User</h5>
</section>
<section class="Tab4">
    <a class="Accent Decoration-none" href="https://www.unischools.co.za/"><h5>Teachers click here</h5></a>
</section>
</div>
';
?>