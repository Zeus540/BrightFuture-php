<?php
echo '
<div class="Intro-Text ">
<section>
        <img id="middle-left-cloud" src="../assets/images/Group17.png" alt="">
</section>
<section>
   <p id="intro-Text">In Hygienica, you’ll enjoy loads of fun-filled hygiene adventures where you’ll learn all about washing
        your hands, brushing your teeth and spotting invisible germs with your friends Sizwe and Lizzy.
        As you venture through the castle  you’ll also earn tons of germ-busting bucks which you can
        redeem for awesome real-life prizes for you and your family!
        <br>
        <br>
        <span><strong>Are you a teacher? Click <a href="https://www.unischools.co.za/">here</a> to log in</strong></span></p>
</section>
</div>
';
?>