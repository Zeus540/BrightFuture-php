<?php
echo '
<div class="Mobi-header">
<section class="Mobi-Banner">
    <a href="/"><img id="Banner-top-center" src="../assets/images/VectorSmartObject.png" alt="" width="100%"></a>
</section>
</div>
';
?>